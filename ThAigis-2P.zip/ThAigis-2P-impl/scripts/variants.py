import numpy as np, json, sys
from thaigis_model import *
key=sys.argv[1]
CHOICE = {'I':(1.25, 670000), 'II':(0.75,1300000), 'III':(0.6,1600000)}
nu, r0 = CHOICE[key]
P=SETS[key]; k,l=P['k'],P['l']; D=N*(k+l)
rng=np.random.default_rng(99)
# spectral distribution
S=np.concatenate([spectral_S(*sample_shares(P,2000,rng),nu) for _ in range(5)])
Smean=N*(l*var_unif(P['eta1'])/nu**2+k*var_unif(P['eta2'])); Btyp=np.sqrt(TAU*Smean)
keys=[rng.integers(-(2**(P['d']-1))+1, 2**(P['d']-1)+1, size=(k,N)) for _ in range(12)]
def pglob(r, n=12000):
    tot=0
    for t0 in keys: tot+=global_checks(P,nu,r,t0,n//len(keys),rng).mean()
    return tot/len(keys)
variants={
 'main (pE=1/2, eps=2^-128)': (np.sqrt(TAU*np.quantile(S,0.5)), -128),
 'pE=0.9, eps=2^-128':        (np.sqrt(TAU*np.quantile(S,0.9)), -128),
 'pE=1/2, eps=2^-64':         (np.sqrt(TAU*np.quantile(S,0.5)), -64),
 'heuristic 1.3*Btyp, eps=2^-64 (Celi-style)': (1.3*Btyp, -64),
 'l1 bound tau*eta*sqrt(..), eps=2^-128': (TAU*np.sqrt(N*(l*P['eta1']**2/nu**2+k*P['eta2']**2)), -128),
}
out={}
grid=np.linspace(0.6*r0,1.25*r0,14)
pg_cache={r:pglob(r, 6000) for r in grid}
for name,(B,le) in variants.items():
    phi=phi_of_eps(D,le); best=None
    for r in grid:
        if nu*r>(P['q']-1)/2-2000: continue
        rp=rprime(r,B,phi); M=np.exp(log_M(r,rp,D)); ps=pg_cache[r]/M**2
        if best is None or ps>best['pslot']: best=dict(r=float(r),rp=rp,M=float(M),pglob=float(pg_cache[r]),pslot=float(ps))
    ps=best['pslot']; K50=int(np.ceil(np.log(.5)/np.log(1-ps))) if ps<1 else 1; K90=int(np.ceil(np.log(.1)/np.log(1-ps)))
    out[name]=dict(B=float(B),B_over_Btyp=float(B/Btyp),phi=phi,**best,K50=K50,K90=K90)
    print(f"{key} | {name}: B={B:.0f} ({B/Btyp:.2f}x) phi={phi:.3f} r={best['r']:.0f} M={best['M']:.3f} pglob={best['pglob']:.3f} pslot={ps:.4f} K50={K50} K90={K90}",flush=True)
# key-averaged model at the chosen point
Bm=np.sqrt(TAU*np.ceil(np.quantile(S,0.5)))
pg=pglob(r0, int(sys.argv[2]) if len(sys.argv)>2 else 24000)
out['model_at_choice']=dict(r=r0,pglob_keyavg=float(pg))
print(f"{key} model at chosen r={r0}: key-averaged pglob={pg:.4f}")
json.dump(out,open(f'../results/variants_{key}.json','w'),indent=1)
