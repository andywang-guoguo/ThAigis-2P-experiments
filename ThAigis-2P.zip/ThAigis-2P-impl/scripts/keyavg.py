import numpy as np, sys, json
from thaigis_model import *
CHOICE = {'I':(1.25, 670000), 'II':(0.75,1300000), 'III':(0.6,1600000)}
key=sys.argv[1]; nu,r=CHOICE[key]; P=SETS[key]; k=P['k']
rng=np.random.default_rng(int(sys.argv[2]))
res=[]
for t in range(int(sys.argv[3])):
    t0=rng.integers(-(2**(P['d']-1))+1, 2**(P['d']-1)+1, size=(k,N))
    oz,od,oh,zi,wt,dl=global_checks(P,nu,r,t0,2000,rng,return_parts=True)
    res.append((oz.mean(),od.mean(),oh.mean(),(oz&od&oh).mean(),wt.mean()))
res=np.array(res); print(key, "keys=%d pz=%.4f pd=%.5f ph=%.4f pglob=%.4f (sd over keys %.4f) Ewt=%.2f"%(len(res),*res[:,:4].mean(0),res[:,3].std(),res[:,4].mean()))
json.dump(dict(set=key,pz=res[:,0].mean(),pd=res[:,1].mean(),ph=res[:,2].mean(),pglob=res[:,3].mean(),pglob_sd_keys=res[:,3].std(),Ewt=res[:,4].mean(),keys=len(res)),open(f'../results/keyavg_{key}.json','w'))
