import numpy as np, sys, json
from thaigis_model import *
rng = np.random.default_rng(7)
key = sys.argv[1]; log2eps = float(sys.argv[2])
P = SETS[key]; k,l = P['k'],P['l']; D = N*(k+l)
phi = phi_of_eps(D, log2eps)
t0 = rng.integers(-(2**(P['d']-1))+1, 2**(P['d']-1)+1, size=(k,N))
res=[]
for nu in [1.0,1.25,1.5,1.75,2.0,2.5]:
    s1,s2 = sample_shares(P, 3000, rng)
    S = spectral_S(s1,s2,nu); B = np.sqrt(TAU*np.quantile(S,0.5))
    best=None
    for r in np.linspace(250000, 1300000, 22):
        if nu*r > (P['q']-1)/2 - 2000: continue
        rp = rprime(r,B,phi); lM = log_M(r,rp,D); pacc = np.exp(-lM)
        g = global_checks(P, nu, r, t0, 1500, rng).mean()
        ps = pacc**2 * g
        res.append(dict(nu=nu,r=r,B=B,phi=phi,M=np.exp(lM),pacc=pacc,pglob=g,pslot=ps))
        if best is None or ps>best[0]: best=(ps,r,np.exp(lM),g)
    print(f"{key} eps=2^{log2eps} phi={phi:.3f} nu={nu}: B={B:.0f} best pslot={best[0]:.4f} at r={best[1]:.0f} (M={best[2]:.3f}, pglob={best[3]:.3f})", flush=True)
json.dump(res, open(f'../results/grid_{key}_{int(-log2eps)}.json','w'))
