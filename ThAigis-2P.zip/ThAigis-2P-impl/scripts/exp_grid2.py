import numpy as np, sys, json
from thaigis_model import *
rng = np.random.default_rng(11)
key = sys.argv[1]; log2eps = float(sys.argv[2]); nus=[float(x) for x in sys.argv[3].split(',')]; rlo,rhi,rn=[float(x) for x in sys.argv[4].split(',')]
P = SETS[key]; k,l = P['k'],P['l']; D = N*(k+l)
phi = phi_of_eps(D, log2eps)
t0 = rng.integers(-(2**(P['d']-1))+1, 2**(P['d']-1)+1, size=(k,N))
out=[]
for nu in nus:
    s1,s2 = sample_shares(P, 3000, rng)
    S = spectral_S(s1,s2,nu); B = np.sqrt(TAU*np.quantile(S,0.5))
    line=[]
    for r in np.linspace(rlo,rhi,int(rn)):
        if nu*r > (P['q']-1)/2 - 2000: continue
        rp = rprime(r,B,phi); lM = log_M(r,rp,D); pacc = np.exp(-lM)
        oz,od,oh,_,_,_ = global_checks(P, nu, r, t0, 2000, rng, return_parts=True)
        g=(oz&od&oh).mean(); ps = pacc**2 * g
        line.append((ps,r,np.exp(lM),g,oz.mean(),oh.mean()))
        out.append(dict(nu=nu,r=r,B=B,phi=phi,M=float(np.exp(lM)),pglob=float(g),pz=float(oz.mean()),ph=float(oh.mean()),pslot=float(ps)))
    b=max(line)
    print(f"{key} nu={nu}: B={B:.0f} best pslot={b[0]:.4f} r={b[1]:.0f} M={b[2]:.3f} pglob={b[3]:.3f} (pz={b[4]:.3f}, ph={b[5]:.3f})", flush=True)
json.dump(out, open(f'../results/grid2_{key}_{int(-log2eps)}.json','w'))
