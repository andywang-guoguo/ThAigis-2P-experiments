#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "aigis/sign.h"
#include "aigis/ntt.h"
#include "aigis/reduce.h"
#include "aigis/poly.h"
#include "utils/randombytes.h"
static double now(){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
/* schoolbook negacyclic mult mod q */
static void school(int64_t *c,const int64_t*a,const int64_t*b){for(int i=0;i<PARAM_N;i++)c[i]=0;
 for(int i=0;i<PARAM_N;i++)for(int j=0;j<PARAM_N;j++){int64_t p=(a[i]*b[j])%PARAM_Q; if(i+j<PARAM_N)c[i+j]=(c[i+j]+p)%PARAM_Q; else c[i+j-PARAM_N]=(c[i+j-PARAM_N]-p+PARAM_Q)%PARAM_Q;}}
int main(){
  printf("mode=%d q=%d pk=%d sk=%d sig=%d\n",AIGIS_SIG_MODE,PARAM_Q,CRYPTO_PUBLICKEYBYTES,CRYPTO_SECRETKEYBYTES,CRYPTO_BYTES);
  /* NTT check */
  for(int t=0;t<20;t++){ poly a,b,c; int64_t A[PARAM_N],B[PARAM_N],C[PARAM_N]; unsigned char r[8*PARAM_N]; randombytes(r,sizeof r);
    for(int i=0;i<PARAM_N;i++){uint32_t x,y; memcpy(&x,r+8*i,4); memcpy(&y,r+8*i+4,4); A[i]=x%PARAM_Q; B[i]=y%PARAM_Q; a.coeffs[i]=A[i]; b.coeffs[i]=B[i];}
    poly_ntt(&a); poly_ntt(&b); poly_pointwise_invmontgomery(&c,&a,&b); poly_invntt_montgomery(&c);
    school(C,A,B); for(int i=0;i<PARAM_N;i++){ if(freeze4q(c.coeffs[i])!=C[i]){printf("NTT mismatch\n");return 1;}}
  }
  printf("NTT multiplication == schoolbook (20 random pairs)\n");
  unsigned char pk[CRYPTO_PUBLICKEYBYTES], sk[CRYPTO_SECRETKEYBYTES], sig[CRYPTO_BYTES]; size_t sl;
  unsigned char m[64]; unsigned char ctx[32];
  int N=2000, okc=0, bad=0; double tk=0,ts=0,tv=0;
  for(int it=0;it<N;it++){
    randombytes(m,64); randombytes(ctx,32);
    double t0=now(); crypto_sign_keypair(pk,sk); double t1=now();
    crypto_sign_signature(sig,&sl,m,64,ctx,(it%2)?32:0,sk); double t2=now();
    int r=crypto_sign_verify(sig,sl,m,64,ctx,(it%2)?32:0,pk); double t3=now();
    tk+=t1-t0; ts+=t2-t1; tv+=t3-t2; if(r==0)okc++;
    m[it%64]^=1; if(crypto_sign_verify(sig,sl,m,64,ctx,(it%2)?32:0,pk)==0) bad++;
  }
  printf("native: %d/%d verify ok, %d forged-accepts; keygen %.1f us, sign %.1f us, verify %.1f us\n",okc,N,bad,tk/N*1e6,ts/N*1e6,tv/N*1e6);
  return 0;}
