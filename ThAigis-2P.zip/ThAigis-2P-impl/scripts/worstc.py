import numpy as np, json, sys
from thaigis_model import *
fp=json.load(open('../results/final_params.json'))
rng=np.random.default_rng(int(sys.argv[2]))
key=sys.argv[1]; P=SETS[key]; nu=fp[key]['nu']; k,l=P['k'],P['l']
s1,s2=sample_shares(P,1,rng); S=spectral_S(s1,s2,nu)[0]
e1=np.abs(eval_odd_roots(s1[0]))**2; e2=np.abs(eval_odd_roots(s2[0]))**2
Sj=e1.sum(0)/nu**2+e2.sum(0)           # S_j for all n roots
tw=np.exp(-1j*np.pi*np.arange(N)/N)
def val(c): return (np.abs(np.fft.fft(c*tw))**2*Sj).sum()/N
best_overall=0
for restart in range(6):
    c=np.zeros(N); pos=rng.choice(N,TAU,replace=False); c[pos]=rng.choice([-1,1],TAU); v=val(c)
    improved=True; it=0
    while improved and it<60:
        improved=False; it+=1
        nz=np.nonzero(c)[0]; z=np.nonzero(c==0)[0]
        for i in rng.permutation(nz):
            # try flip sign
            c2=c.copy(); c2[i]*=-1; v2=val(c2)
            if v2>v: c,v=c2,v2; improved=True; continue
            # try move to a random zero position
            for j in rng.choice(np.nonzero(c==0)[0],8,replace=False):
                c2=c.copy(); c2[j]=c[i]; c2[i]=0; v2=val(c2)
                if v2>v: c,v=c2,v2; improved=True; break
    best_overall=max(best_overall,v)
rand=max(val(cc) for cc in sample_challenge(2000,rng).astype(float))
print(key,"tau*S=%.0f random-max ratio=%.3f (norm %.3f) local-search ratio=%.3f (norm %.3f)"%(TAU*S,rand/(TAU*S),np.sqrt(rand/(TAU*S)),best_overall/(TAU*S),np.sqrt(best_overall/(TAU*S))))
