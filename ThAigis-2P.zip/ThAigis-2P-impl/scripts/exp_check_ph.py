import numpy as np
from thaigis_model import *
rng=np.random.default_rng(5)
P=SETS['I']; nu,r=1.25,670000; k=P['k']
for trial in range(4):
    t0 = rng.integers(-(2**(P['d']-1))+1, 2**(P['d']-1)+1, size=(k,N))
    oz,od,oh,zi,wt,dl = global_checks(P,nu,r,t0,20000,rng,return_parts=True)
    print(trial, "ph=%.4f pz=%.4f E|delta|=%.1f Ewt=%.2f ||t0||^2/E=%.4f"%(oh.mean(),oz.mean(),np.abs(dl).mean(),wt.mean(), (t0.astype(float)**2).sum()/(k*N*(2**(2*P['d']))/12)))
