import numpy as np, sys
from thaigis_model import *
rng = np.random.default_rng(1)
for key in ['I','II','III']:
    P = SETS[key]; k,l = P['k'],P['l']
    for nu in [1.0, 1.5, 2.0, 3.0]:
        s1,s2 = sample_shares(P, 4000, rng)
        S = spectral_S(s1, s2, nu)
        Btyp2 = TAU*N*(l*var_unif(P['eta1'])/nu**2 + k*var_unif(P['eta2']))
        Smean = N*(l*var_unif(P['eta1'])/nu**2 + k*var_unif(P['eta2']))
        qs = np.quantile(S, [0.1,0.5,0.9,0.99])
        print(f"{key} nu={nu}: Btyp={np.sqrt(Btyp2):.1f}  S/Smean quantiles(10,50,90,99%)= {np.round(qs/Smean,3)}  B_spec(p_E=.5)/Btyp={np.sqrt(qs[1]/Smean):.3f}  (p_E=.9)/Btyp={np.sqrt(qs[2]/Smean):.3f}")
    # validate bound vs. actual for a few shares
    nu=2.0
    s1,s2 = sample_shares(P, 5, rng); S = spectral_S(s1,s2,nu)
    cs = sample_challenge(3000, rng)
    for b in range(5):
        vals=[]
        for c in cs:
            v1 = negacyclic_mul(c, s1[b]); v2 = negacyclic_mul(c, s2[b])
            vals.append((v1**2).sum()/nu**2 + (v2**2).sum())
        vals=np.array(vals)
        print(f"  share{b}: tau*S={TAU*S[b]:.0f}  max_c||L^-1cu||^2 over 3000 c = {vals.max():.0f}  mean={vals.mean():.0f}  ratio max/bound={vals.max()/(TAU*S[b]):.3f}  violated={np.any(vals>TAU*S[b]*(1+1e-12))}")
