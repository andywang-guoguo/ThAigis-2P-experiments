#include <stdio.h>
#include <string.h>
#include "hash/keccak/fips202.h"
int main(int argc,char**argv){
  /* read hex input from argv[1], output shake128 then shake256 of 600 bytes, also incremental */
  unsigned char in[4096]; size_t n=0; const char*h=argv[1];
  for(size_t i=0;h[i]&&h[i+1];i+=2){unsigned v; sscanf(h+i,"%2x",&v); in[n++]=v;}
  unsigned char o[600];
  shake128(o,600,in,n); for(int i=0;i<600;i++)printf("%02x",o[i]); printf("\n");
  shake256(o,600,in,n); for(int i=0;i<600;i++)printf("%02x",o[i]); printf("\n");
  keccak_state st; shake256_init(&st); shake256_absorb(&st,in,n/3); shake256_absorb(&st,in+n/3,n-n/3); shake256_finalize(&st);
  shake256_squeeze(o,100,&st); shake256_squeeze(o+100,500,&st);
  for(int i=0;i<600;i++)printf("%02x",o[i]); printf("\n");
  return 0;}
