import numpy as np, json, math
from math import sqrt, log2, lgamma, log
from thaigis_model import *
from coresvp import dual_cost, primal_beta
fp=json.load(open('../results/final_params.json'))
out={}
for key in ['I','II','III']:
    P=SETS[key]; k,l,q=P['k'],P['l'],P['q']; D=N*(k+l); nu=fp[key]['nu']; r=fp[key]['r']; rp=fp[key]['rp']
    # (a) dual attack for chi_r (continuous approx stds)
    ss=nu*rp/sqrt(D+2); se=rp/sqrt(D+2)
    dc=dual_cost(q,N*l,N*k,ss,se,bmax=1200)
    # (b) phi for eps=2^-64 truncated
    phi64=math.floor(phi_of_eps(D,-64)*1e4)/1e4
    # (c) normal approx of ||delta||_inf > gamma2
    sd=sqrt(2*(r/sqrt(D+2))**2+TAU*2**(2*P['d'])/12)
    from scipy.stats import norm
    pdel=1-(1-2*norm.sf(P['g2']/sd))**(N*k)
    # (f) min-entropy: H(y) >= log2 Vol(B_D(r')) + n l log2 nu ; support of y1 <= (2 nu r'+1)^{nl}
    logvol=(D/2)*log2(math.pi)+D*log2(rp)-lgamma(D/2+1)/math.log(2)
    Hy=logvol+N*l*log2(nu); Hw=Hy-N*l*log2(2*nu*rp+1); surplus=Hy-N*k*log2(q)
    out[key]=dict(dual_chi_r=dc, phi64=phi64, pdelta_fail=pdel, Hy=Hy, Hw_lower=Hw, surplus=surplus)
    print(key, "dual(chi_r)=",None if dc is None else (round(dc[0],1),dc[1],dc[2]), "phi64=",phi64, "P(delta fail)=%.2e"%pdel, "H(y)>=%.0f H(w)>=%.0f surplus=%.0f"%(Hy,Hw,surplus))
json.dump(out,open('../results/extra_checks.json','w'),indent=1)
