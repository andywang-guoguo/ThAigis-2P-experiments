import json
from math import sqrt
from coresvp import primal_beta, dual_cost
from thaigis_model import SETS, var_unif, N
fp=json.load(open('../results/final_params.json'))
out={}
for key,P in SETS.items():
    k,l,q=P['k'],P['l'],P['q']; ns=N*l; m=N*k; D=N*(k+l)
    ss=sqrt(var_unif(P['eta1'])); se=sqrt(var_unif(P['eta2']))
    nu=fp[key]['nu']; r=fp[key]['r']; rp=fp[key]['rp']
    rows={}
    for name,(a,b) in {'native share (Aigis-sig key dist.)':(ss,se),
                        'joint key s=s^(0)+s^(1)':(ss*sqrt(2),se*sqrt(2)),
                        'chi_r (commitment)':(nu*rp/sqrt(D+2), rp/sqrt(D+2)),
                        'chi_z (target)':(nu*r/sqrt(D+2), r/sqrt(D+2))}.items():
        pb=primal_beta(q,ns,m,a,b)
        dc=dual_cost(q,ns,m,a,b) if pb is not None and pb[0]<1500 else None
        rows[name]=dict(sigma_s=a,sigma_e=b,primal_beta=None if pb is None else pb[0],primal_m=None if pb is None else pb[1],
                        primal_classical=None if pb is None else 0.292*pb[0], primal_quantum=None if pb is None else 0.265*pb[0],
                        dual_classical=None if dc is None else dc[0], dual_beta=None if dc is None else dc[1])
        print(key, name, rows[name], flush=True)
    out[key]=rows
json.dump(out,open('../results/security_est.json','w'),indent=1)
