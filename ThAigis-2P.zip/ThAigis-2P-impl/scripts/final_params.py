import numpy as np, json, sys
from thaigis_model import *
from mpmath import mpf, log as mlog
CHOICE = {'I':(1.25, 670000), 'II':(0.75,1300000), 'III':(0.6,1600000)}
LOG2EPS = -128
rng = np.random.default_rng(2026)
out = {}
for key,(nu,r) in CHOICE.items():
    P = SETS[key]; k,l = P['k'],P['l']; D=N*(k+l)
    # spectral threshold: median over 20000 native shares
    Ss=[]
    for _ in range(10):
        s1,s2 = sample_shares(P,2000,rng); Ss.append(spectral_S(s1,s2,nu))
    S = np.concatenate(Ss)
    Smean = N*(l*var_unif(P['eta1'])/nu**2 + k*var_unif(P['eta2']))
    S_thr = float(np.ceil(np.quantile(S,0.5)))
    pE = float((S<=S_thr).mean())
    B = int(np.ceil(np.sqrt(TAU*S_thr)))
    Btyp = float(np.sqrt(TAU*Smean))
    phi = phi_of_eps(D, LOG2EPS); phi = float(np.floor(phi*1e4)/1e4)
    eps = eps_of_phi(D, phi); log2eps = float(mlog(eps,2))
    rp = rprime(r,B,phi); lM = float(log_M(r,rp,D)); M=float(np.exp(lM))
    t0 = rng.integers(-(2**(P['d']-1))+1, 2**(P['d']-1)+1, size=(k,N))
    oz=[];od=[];oh=[];wts=[];zinf=[];dinf=[]
    for _ in range(25):
        a,b,c,zi,wt,dl = global_checks(P,nu,r,t0,2000,rng,return_parts=True)
        oz.append(a);od.append(b);oh.append(c);wts.append(wt);zinf.append(zi);dinf.append(np.abs(dl).max(axis=1))
    oz=np.concatenate(oz);od=np.concatenate(od);oh=np.concatenate(oh);wts=np.concatenate(wts);zinf=np.concatenate(zinf);dinf=np.concatenate(dinf)
    pg=float((oz&od&oh).mean()); pacc=1/M; ps=pacc**2*pg
    Kfor=lambda tgt: int(np.ceil(np.log(1-tgt)/np.log(1-ps)))
    sig_z1 = nu*r/np.sqrt(D+2); sig_z2=r/np.sqrt(D+2)
    out[key]=dict(set=P['name'],nu=nu,r=r,rp=rp,B=B,Btyp=Btyp,B_over_Btyp=B/Btyp,S_thr=S_thr,S_over_mean=S_thr/Smean,pE=pE,
                  phi=phi,log2eps=log2eps,M=M,pacc=pacc,pz=float(oz.mean()),pd=float(od.mean()),ph=float(oh.mean()),pglob=pg,pslot=ps,
                  K50=Kfor(0.5),K90=Kfor(0.9),K99=Kfor(0.99),wt_mean=float(wts.mean()),wt_p99=float(np.quantile(wts,0.99)),
                  zinf_mean=float(zinf.mean()),dinf_max=float(dinf.max()),sig_z1_party=float(sig_z1),sig_z2_party=float(sig_z2),
                  nu_r_over_halfq=float(nu*rp/((P['q']-1)/2)),D=D,MCsamples=len(oz))
    o=out[key]
    print(f"{key}: nu={nu} r={r} r'={rp} B={B} (Btyp={Btyp:.0f}, x{B/Btyp:.3f}) pE={pE:.3f} phi={phi} eps=2^{log2eps:.1f} M={M:.4f} pacc={pacc:.4f}")
    print(f"     pz={o['pz']:.4f} pd={o['pd']:.4f} ph={o['ph']:.4f} pglob={pg:.4f} pslot={ps:.4f} K50={o['K50']} K90={o['K90']} K99={o['K99']} E[wt]={o['wt_mean']:.1f} (omega={P['omega']}) wt99={o['wt_p99']:.0f}")
    print(f"     sigma(z1 per party)={sig_z1:.0f} sigma(z2 per party)={sig_z2:.0f} max|delta|={o['dinf_max']:.0f} (g2={P['g2']}) nu r'/(q/2)={o['nu_r_over_halfq']:.3f}")
json.dump(out, open('../results/final_params.json','w'), indent=1)
