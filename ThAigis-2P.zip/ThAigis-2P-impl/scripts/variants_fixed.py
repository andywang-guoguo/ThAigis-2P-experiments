import numpy as np, json
from thaigis_model import *
fp=json.load(open('../results/final_params.json'))
rng=np.random.default_rng(42)
out={}
for key in ['I','II','III']:
    P=SETS[key]; k,l=P['k'],P['l']; D=N*(k+l); nu=fp[key]['nu']; r=fp[key]['r']
    pg=json.load(open(f'../results/keyavg_{key}.json'))['pglob']
    S=np.concatenate([spectral_S(*sample_shares(P,2000,rng),nu) for _ in range(5)])
    Smean=N*(l*var_unif(P['eta1'])/nu**2+k*var_unif(P['eta2'])); Btyp=np.sqrt(TAU*Smean)
    Bl1=TAU*np.sqrt(N*(l*P['eta1']**2/nu**2+k*P['eta2']**2))
    V=[('本文主配置 (p_E=1/2, ε=2^-128)', fp[key]['B'], -128),
       ('p_E=0.9, ε=2^-128', np.sqrt(TAU*np.quantile(S,0.9)), -128),
       ('p_E=1/2, ε=2^-64', fp[key]['B'], -64),
       ('启发式界 1.3·B_typ, ε=2^-64', 1.3*Btyp, -64),
       ('启发式界 1.3·B_typ, ε=2^-128', 1.3*Btyp, -128),
       ('ℓ1 确定性界, ε=2^-128', Bl1, -128)]
    rows=[]
    for name,B,le in V:
        phi=phi_of_eps(D,le); rp=rprime(r,B,phi); lM=float(log_M(r,rp,D)); M=np.exp(lM)
        ps=pg/M**2; K50=int(np.ceil(np.log(.5)/np.log1p(-ps))); K90=int(np.ceil(np.log(.1)/np.log1p(-ps)))
        rows.append(dict(name=name,B=float(B),ratio=float(B/Btyp),log2eps=le,phi=phi,rp=rp,M=M,pacc=1/M,pslot=ps,K50=K50,K90=K90))
        print(f"{key} | {name}: B={B:.0f} ({B/Btyp:.2f}x) phi={phi:.4f} r'={rp} M={M:.4g} pacc={1/M:.4g} pslot={ps:.4g} K50={K50} K90={K90}")
    out[key]=dict(Btyp=float(Btyp),pglob=pg,rows=rows)
json.dump(out,open('../results/variants_fixed.json','w'),indent=1,ensure_ascii=False)
