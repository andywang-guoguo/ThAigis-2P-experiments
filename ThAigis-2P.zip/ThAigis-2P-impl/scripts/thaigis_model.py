"""Numerical model for ThAigis-2P parameters.

All quantities follow the paper's notation:
  n=256, (k,l), q, d, gamma1, gamma2, eta1, eta2, beta1, beta2, omega, tau=60
  L_nu = diag(nu*I_{nl}, I_{nk}),  D = n(k+l)
  spectral statistic  S(u) = max_zeta sum_p w_p |u_p(zeta)|^2,  w = 1/nu^2 (s1 part), 1 (s2 part)
  deterministic bound ||L_nu^{-1} c u||_2^2 <= tau * S(u)  for every c with tau entries in {+-1}
"""
import numpy as np
from mpmath import mp, betainc, mpf, findroot, log as mplog
mp.dps = 60

SETS = {
    'I':   dict(name='Aigis-sig-I',   q=2021377, d=13, k=4, l=3, eta1=2, eta2=3, beta1=120, beta2=175, omega=80,  g1=131072, g2=168448, qbits=21),
    'II':  dict(name='Aigis-sig-II',  q=3870721, d=14, k=5, l=4, eta1=2, eta2=5, beta1=120, beta2=275, omega=96,  g1=131072, g2=322560, qbits=22),
    'III': dict(name='Aigis-sig-III', q=3870721, d=14, k=6, l=5, eta1=1, eta2=5, beta1=60,  beta2=275, omega=120, g1=131072, g2=322560, qbits=22),
}
N = 256
TAU = 60

def var_unif(eta):
    return eta * (eta + 1) / 3.0

# ---------------------------------------------------------------- spectral statistic
_tw = np.exp(-1j * np.pi * np.arange(N) / N)   # twist so that FFT gives evaluations at odd roots

def eval_odd_roots(polys):
    """polys: (..., N) real -> (..., N) complex evaluations at the N roots of X^N+1 (up to conjugation)."""
    return np.fft.fft(polys * _tw, axis=-1)

def spectral_S(s1, s2, nu):
    """s1: (B, l, N), s2: (B, k, N) integer arrays.  Returns S(u) for each of B shares."""
    e1 = np.abs(eval_odd_roots(s1)) ** 2       # (B,l,N)
    e2 = np.abs(eval_odd_roots(s2)) ** 2
    S = e1.sum(axis=1) / nu ** 2 + e2.sum(axis=1)
    return S.max(axis=1)

def sample_shares(P, B, rng):
    s1 = rng.integers(-P['eta1'], P['eta1'] + 1, size=(B, P['l'], N))
    s2 = rng.integers(-P['eta2'], P['eta2'] + 1, size=(B, P['k'], N))
    return s1, s2

def sample_challenge(B, rng):
    """B challenges, each with TAU entries in {+-1} at uniform positions (distribution of Aigis 'challenge')."""
    c = np.zeros((B, N), dtype=np.int64)
    for b in range(B):
        pos = rng.choice(N, TAU, replace=False)
        c[b, pos] = rng.choice([-1, 1], TAU)
    return c

def negacyclic_mul(c, f):
    """c: (N,) small int, f: (..., N) int -> c*f mod X^N+1 (exact integers)."""
    out = np.zeros(f.shape, dtype=np.int64)
    for i in np.nonzero(c)[0]:
        sh = np.roll(f, i, axis=-1)
        sh[..., :i] *= -1
        out += c[i] * sh
    return out

# ---------------------------------------------------------------- hyperball covering
def eps_of_phi(D, phi):
    """eps with 2 eps = I_{1-1/phi^2}((D+1)/2, 1/2)  (Devevey et al. Lemma 5.1)."""
    x = 1 - mpf(1) / mpf(phi) ** 2
    return betainc(mpf(D + 1) / 2, mpf(1) / 2, 0, x, regularized=True) / 2

def phi_of_eps(D, log2eps):
    """largest phi with eps(phi) <= 2^log2eps."""
    target = mpf(2) ** log2eps
    lo, hi = mpf('1.0001'), mpf(100)
    for _ in range(200):
        mid = (lo + hi) / 2
        if eps_of_phi(D, mid) <= target:
            lo = mid
        else:
            hi = mid
    return float(lo)

def rprime(r, B, phi):
    return int(np.ceil(np.sqrt(r * r + B * B + 2.0 * r * B / phi)))

def log_M(r, rp, D):
    return D * (np.log(rp) - np.log(r))

# ---------------------------------------------------------------- uniform ball sampling (target distribution)
def sample_ball(Bsz, D, radius, rng):
    g = rng.standard_normal((Bsz, D + 2))
    g /= np.linalg.norm(g, axis=1, keepdims=True)
    return radius * g[:, :D]

# ---------------------------------------------------------------- Aigis decompose (vectorised, exact PQMagic semantics)
def highbits(a, P):
    """a: int array in [0,q). HighBits with alpha=2*gamma2, q-1 = 6 alpha, special case -> 0."""
    q, alpha = P['q'], 2 * P['g2']
    a0 = a % alpha
    a0 = np.where(a0 > alpha // 2, a0 - alpha, a0)      # centred in (-alpha/2, alpha/2]
    hb = (a - a0) // alpha
    hb = np.where(a - a0 == q - 1, 0, hb)
    return hb

def global_checks(P, nu, r, t0, Bsz, rng, return_parts=False):
    """Monte Carlo of Combine for two parties whose accepted responses follow the target distribution.
    t0: (k,N) int array (a real Power2Round low part).  Returns pass indicators."""
    k, l = P['k'], P['l']
    D = N * (k + l)
    zsum1 = np.zeros((Bsz, l * N))
    zsum2 = np.zeros((Bsz, k * N))
    for _ in range(2):
        x = sample_ball(Bsz, D, r, rng)
        zsum1 += np.rint(nu * x[:, :l * N])
        zsum2 += np.rint(x[:, l * N:])
    zinf = np.abs(zsum1).max(axis=1)
    ok_z = zinf < P['g1'] - P['beta1']
    # delta = z2 - c t0
    ct0 = np.zeros((Bsz, k * N))
    cs = sample_challenge(Bsz, rng)
    for b in range(Bsz):
        ct0[b] = negacyclic_mul(cs[b], t0).reshape(-1)
    delta = (zsum2 - ct0).astype(np.int64)
    ok_d = np.abs(delta).max(axis=1) <= P['g2']
    w = rng.integers(0, P['q'], size=(Bsz, k * N))
    v = (w - delta) % P['q']
    wt = (highbits(v, P) != highbits(w, P)).sum(axis=1)
    ok_h = wt <= P['omega']
    if return_parts:
        return ok_z, ok_d, ok_h, zinf, wt, delta
    return ok_z & ok_d & ok_h
