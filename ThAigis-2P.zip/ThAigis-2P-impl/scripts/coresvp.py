"""Core-SVP estimates (ADPS16 methodology, as in the Kyber/Dilithium security scripts) for (A)MLWE.
Primal uSVP with Bai-Galbraith rescaling; dual attack with sieve amortisation (nvec = 0.2075 b)."""
from math import log, sqrt, pi, e, exp
def delta(b): return ((pi*b)**(1./b)*b/(2*pi*e))**(1./(2.*b-2.))
def primal_beta(q, ns, mmax, ss, se, bmax=2500):
    best=None
    for m in range(max(32, ns//8), mmax+1, 8):
        d=ns+m
        logvol = m*log(q) + ns*log(se/ss)          # Bai-Galbraith: scale secret part to std se
        for b in range(50, min(d,bmax)):
            if se*sqrt(b) <= exp((2.*b-d-1)*log(delta(b)) + logvol/d):
                if best is None or b<best[0]: best=(b,m)
                break
    return best
def dual_cost(q, ns, mmax, ss, se, c_svp=0.292, bmax=2500):
    best=None; c=ss/se
    for m in range(max(32, ns//8), mmax+1, 16):
        d=ns+m
        for b in range(50, min(d,bmax), 2):
            l = exp(d*log(delta(b)) + ns*log(c*q)/d)
            tau = l*se/q
            log2eps = -2*pi*pi*tau*tau/log(2)
            cost = c_svp*b + max(0., -2*log2eps - 0.2075*b)
            if best is None or cost<best[0]: best=(cost,b,m)
    return best
if __name__=='__main__':
    pb=primal_beta(3329,512,512,sqrt(1.5),sqrt(1.5)); print("Kyber512 primal beta",pb, "classical %.1f quantum %.1f"%(0.292*pb[0],0.265*pb[0]))
    pb=primal_beta(8380417,1024,1024,sqrt(2),sqrt(2)); print("Dilithium2 primal beta",pb,"classical %.1f quantum %.1f"%(0.292*pb[0],0.265*pb[0]))
    pb=primal_beta(8380417,1280,1536,sqrt(20/3.),sqrt(20/3.)); print("Dilithium3 primal beta",pb)
