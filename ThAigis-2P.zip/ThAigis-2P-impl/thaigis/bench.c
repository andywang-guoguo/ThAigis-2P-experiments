/* Benchmark / statistics driver for ThAigis-2P.
 * usage: bench <nsig> <K> <seed>
 * Prints a JSON object with timings, success statistics and message sizes. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "thaigis.h"
#include "sign.h"
#include "hash/keccak/fips202.h"

static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

/* deterministic seed stream for reproducibility */
static keccak_state RNG; static unsigned char RB[SHAKE256_RATE]; static unsigned RPOS = SHAKE256_RATE;
static void rng_init(unsigned seed) { unsigned char s[16] = "THAIGIS-BENCH"; memcpy(s + 12, &seed, 4); shake256_absorb_once(&RNG, s, 16); }
static void rng_bytes(unsigned char *o, size_t n) {
  while (n--) { if (RPOS == SHAKE256_RATE) { shake256_squeezeblocks(RB, 1, &RNG); RPOS = 0; } *o++ = RB[RPOS++]; }
}

static th_slot SL[2][KMAX];
static th_resp RS[2][KMAX];

int main(int argc, char **argv) {
  int nsig = argc > 1 ? atoi(argv[1]) : 100;
  int K = argc > 2 ? atoi(argv[2]) : 8;
  unsigned seed = argc > 3 ? (unsigned)atoi(argv[3]) : 1;
  if (K > KMAX) K = KMAX;
  rng_init(seed);

  /* ---------------- key generation */
  int nkg = 100; double tkg = 0; long tries = 0;
  th_pub pub; th_share sh[2];
  unsigned char rho[SEEDBYTES], s0[32], s1[32];
  for (int it = 0; it < nkg; it++) {
    rng_bytes(rho, 32); rng_bytes(s0, 32); rng_bytes(s1, 32);
    double t0 = now();
    th_pub_init(&pub, rho);
    th_share_sample(&sh[0], &pub, s0);
    th_share_sample(&sh[1], &pub, s1);
    th_pub_finish(&pub, &sh[0], &sh[1]);
    tkg += now() - t0;
    tries += sh[0].tries + sh[1].tries;
  }
  /* timing of one spectral check */
  double tsp0 = now(); volatile double dummy = 0;
  for (int it = 0; it < 200; it++) dummy += th_spectral(sh[0].s1, sh[0].s2, TH_NU);
  double tspec = (now() - tsp0) / 200;

  /* ---------------- signing */
  long attempts = 0, slots = 0, acc[2] = {0, 0}, both = 0, gpass = 0, why[4] = {0, 0, 0, 0};
  long succK[KMAX + 1]; memset(succK, 0, sizeof succK);
  long verify_ok = 0, verify_fail = 0, hint_sum = 0, hint_n = 0, hint_max = 0;
  double t_off = 0, t_cmt = 0, t_mu = 0, t_ch = 0, t_rej = 0, t_enc = 0, t_comb = 0, t_ver = 0;
  long enc_bytes = 0, enc_n = 0, mode_cnt[3] = {0, 0, 0}, dec_fail = 0;
  double z_sumsq = 0; long z_cnt = 0; int32_t z_absmax = 0;
  unsigned char m[32], ctx[32], sig[CRYPTO_BYTES], mu[CRHBYTES];
  unsigned char wbuf[KMAX * TH_WBYTES + 64], cmt[64];
  unsigned char encb[KMAX][4 * DZ + 64]; size_t encl[KMAX]; int32_t zdec[DZ];
  poly c[KMAX];

  for (int s = 0; s < nsig; s++) {
    if (s % 50 == 0) {                       /* fresh key every 50 signatures: averages key-dependent hint rates */
      rng_bytes(rho, 32); rng_bytes(s0, 32); rng_bytes(s1, 32);
      th_pub_init(&pub, rho); th_share_sample(&sh[0], &pub, s0); th_share_sample(&sh[1], &pub, s1); th_pub_finish(&pub, &sh[0], &sh[1]);
    }
    rng_bytes(m, 32); rng_bytes(ctx, 32);
    int ctxlen = (s & 1) ? 32 : 0;          /* half of the runs use a 32-byte ctx (preprocessing mode) */
    int done = 0;
    while (!done) {
      attempts++;
      /* offline: hyperball samples and commitments (both parties) */
      double t0 = now();
      for (int p = 0; p < 2; p++)
        for (int j = 0; j < K; j++) { unsigned char sd[32]; rng_bytes(sd, 32); th_slot_sample(&SL[p][j], &pub, sd); }
      double t1 = now(); t_off += (t1 - t0) / 2;     /* per party */
      /* round-1 hash commitment of party 0 (per party cost) */
      for (int j = 0; j < K; j++) th_vecw_pack(wbuf + j * TH_WBYTES, &SL[0][j].w);
      shake256(cmt, 32, wbuf, (size_t)K * TH_WBYTES);
      double t2 = now(); t_cmt += t2 - t1;
      /* online: mu and K challenges (computed by each party; timed once) */
      th_mu(mu, &pub, m, 32, ctx, ctxlen);
      double t3 = now(); t_mu += t3 - t2;
      for (int j = 0; j < K; j++) th_challenge(&c[j], mu, &SL[0][j].w, &SL[1][j].w);
      double t4 = now(); t_ch += t4 - t3;
      for (int p = 0; p < 2; p++)
        for (int j = 0; j < K; j++) { th_local_rej(&RS[p][j], &SL[p][j], &sh[p], &c[j]); }
      double t5 = now(); t_rej += (t5 - t4) / 2;
      /* party 1 encodes its accepted responses (sent to the combiner) */
      for (int j = 0; j < K; j++) if (RS[1][j].accepted) {
        int md; encl[j] = th_encode(encb[j], RS[1][j].z1, DZ, &md);
        enc_bytes += encl[j]; enc_n++; mode_cnt[md]++;
      }
      double t6 = now(); t_enc += t6 - t5;
      /* combiner: decode, combine in slot order, verify */
      int okslot = -1;
      for (int j = 0; j < K; j++) if (RS[0][j].accepted && RS[1][j].accepted) {
        if (th_decode(zdec, DZ, encb[j], encl[j]) || memcmp(zdec, RS[1][j].z1, sizeof zdec)) dec_fail++;
        int w; unsigned hw;
        if (th_combine(sig, &pub, &SL[0][j].w, &SL[1][j].w, &c[j], RS[0][j].z1, zdec, &w, &hw) == 0) { okslot = j; break; }
      }
      double t7 = now(); t_comb += t7 - t6;
      if (okslot >= 0) {
        int r = crypto_sign_verify(sig, CRYPTO_BYTES, m, 32, ctx, ctxlen, pub.pk);
        if (r == 0) verify_ok++; else verify_fail++;
        done = 1;
      }
      double t8 = now(); t_ver += t8 - t7;
      /* ---- statistics on every slot (not timed) */
      int first_ok = -1;
      for (int j = 0; j < K; j++) {
        slots++;
        for (int p = 0; p < 2; p++) acc[p] += RS[p][j].accepted;
        for (int p = 0; p < 2; p++) if (RS[p][j].accepted) {
          for (int i = 0; i < DZ; i++) { int32_t v = RS[p][j].z1[i]; z_sumsq += (double)v * v; z_cnt++; if (abs(v) > z_absmax) z_absmax = abs(v); }
        }
        if (RS[0][j].accepted && RS[1][j].accepted) {
          both++;
          int w; unsigned hw; unsigned char sg[CRYPTO_BYTES];
          if (th_combine(sg, &pub, &SL[0][j].w, &SL[1][j].w, &c[j], RS[0][j].z1, RS[1][j].z1, &w, &hw) == 0) {
            gpass++; if (first_ok < 0) first_ok = j;
          } else why[w]++;
          if (w == 0 || w == 3) { hint_sum += hw; hint_n++; if ((long)hw > hint_max) hint_max = hw; }
        }
      }
      for (int kk = 1; kk <= K; kk++) if (first_ok >= 0 && first_ok < kk) succK[kk]++;
    }
  }
  double A = (double)attempts;
  printf("{\"set\":%d,\"K\":%d,\"nsig\":%d,\"seed\":%u,\n", PARAMS, K, nsig, seed);
  printf(" \"keygen_ms\":%.4f,\"share_tries_avg\":%.4f,\"spectral_check_ms\":%.4f,\n", tkg / nkg * 1e3, tries / (2.0 * nkg), tspec * 1e3);
  printf(" \"attempts\":%ld,\"attempts_per_sig\":%.4f,\"slots\":%ld,\"p_acc_party0\":%.5f,\"p_acc_party1\":%.5f,\"p_both\":%.5f,\"p_glob_given_both\":%.5f,\"p_slot\":%.5f,\n",
         attempts, A / nsig, slots, acc[0] / (double)slots, acc[1] / (double)slots, both / (double)slots, gpass / (double)both, gpass / (double)slots);
  printf(" \"fail_z\":%ld,\"fail_delta\":%ld,\"fail_hint\":%ld,\"hint_mean\":%.3f,\"hint_max\":%ld,\n", why[1], why[2], why[3], hint_sum / (double)hint_n, hint_max);
  printf(" \"succ_by_K\":[");
  for (int kk = 1; kk <= K; kk++) printf("%.5f%s", succK[kk] / A, kk < K ? "," : "");
  printf("],\n");
  printf(" \"verify_ok\":%ld,\"verify_fail\":%ld,\"decode_fail\":%ld,\n", verify_ok, verify_fail, dec_fail);
  printf(" \"t_offline_per_party_ms\":%.4f,\"t_slot_ms\":%.4f,\"t_cmt_hash_ms\":%.4f,\"t_mu_ms\":%.4f,\"t_challenges_ms\":%.4f,\"t_localrej_per_party_ms\":%.4f,\"t_encode_ms\":%.4f,\"t_combine_ms\":%.4f,\"t_verify_ms\":%.4f,\n",
         t_off / A * 1e3, t_off / A / K * 1e3, t_cmt / A * 1e3, t_mu / A * 1e3, t_ch / A * 1e3, t_rej / A * 1e3, t_enc / A * 1e3, t_comb / A * 1e3, t_ver / nsig * 1e3);
  printf(" \"enc_avg_bytes\":%.2f,\"enc_n\":%ld,\"mode_N\":%ld,\"mode_R\":%ld,\"mode_C\":%ld,\"raw_R_bytes\":%d,\"w_bytes\":%d,\n",
         enc_bytes / (double)enc_n, enc_n, mode_cnt[0], mode_cnt[1], mode_cnt[2], 1 + (DZ * QBITS + 7) / 8, TH_WBYTES);
  printf(" \"z1_party_std\":%.2f,\"z1_party_absmax\":%d}\n", sqrt(z_sumsq / z_cnt), z_absmax);
  (void)dummy;
  return 0;
}
