/* ThAigis-2P core routines.  See thaigis.h. */
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "thaigis.h"
#include "sign.h"
#include "packing.h"
#include "rounding.h"
#include "reduce.h"
#include "ntt.h"
#include "hash/keccak/fips202.h"

static inline int32_t center(uint32_t a) {          /* a in [0,q) -> (-q/2, q/2] */
  return (a > (PARAM_Q - 1) / 2) ? (int32_t)a - PARAM_Q : (int32_t)a;
}
static inline uint32_t modq(int64_t x) {
  int64_t r = x % PARAM_Q;
  if (r < 0) r += PARAM_Q;
  return (uint32_t)r;
}

/* ------------------------------------------------------------------ spectral statistic
 * S(u) = max_j  sum_p w_p |u_p(zeta_j)|^2 , zeta_j = exp(i*pi*(2j+1)/n), w = 1/nu^2 on s1, 1 on s2.
 * For every c with tau coefficients in {+-1}:  ||L_nu^{-1} c u||_2^2 <= tau * S(u)  (Parseval). */
static double COS2N[2 * PARAM_N], SIN2N[2 * PARAM_N];
static int trig_ready = 0;
static void trig_init(void) {
  if (trig_ready) return;
  for (int m = 0; m < 2 * PARAM_N; m++) {
    COS2N[m] = cos(M_PI * m / PARAM_N);
    SIN2N[m] = sin(M_PI * m / PARAM_N);
  }
  trig_ready = 1;
}
static void poly_eval_sq(double *out, const int32_t *f) {   /* out[j] = |f(zeta_j)|^2, j < n/2 */
  for (int j = 0; j < PARAM_N / 2; j++) {
    double re = 0, im = 0;
    int step = 2 * j + 1, idx = 0;
    for (int k = 0; k < PARAM_N; k++) {
      re += f[k] * COS2N[idx];
      im += f[k] * SIN2N[idx];
      idx += step;
      if (idx >= 2 * PARAM_N) idx -= 2 * PARAM_N;
    }
    out[j] = re * re + im * im;
  }
}
double th_spectral(const int32_t *s1, const int32_t *s2, double nu) {
  double acc[PARAM_N / 2], tmp[PARAM_N / 2], best = 0;
  trig_init();
  memset(acc, 0, sizeof acc);
  for (int p = 0; p < PARAM_L; p++) {
    poly_eval_sq(tmp, s1 + p * PARAM_N);
    for (int j = 0; j < PARAM_N / 2; j++) acc[j] += tmp[j] / (nu * nu);
  }
  for (int p = 0; p < PARAM_K; p++) {
    poly_eval_sq(tmp, s2 + p * PARAM_N);
    for (int j = 0; j < PARAM_N / 2; j++) acc[j] += tmp[j];
  }
  for (int j = 0; j < PARAM_N / 2; j++) if (acc[j] > best) best = acc[j];
  return best * (1.0 + 1e-9);   /* conservative margin for floating-point error */
}

/* ------------------------------------------------------------------ keys */
void th_pub_init(th_pub *pub, const unsigned char rho[SEEDBYTES]) {
  memcpy(pub->rho, rho, SEEDBYTES);
  expand_mat(pub->mat, rho);
}

void th_share_sample(th_share *sh, const th_pub *pub, const unsigned char seed[32]) {
  unsigned char in[33], sseed[SEEDBYTES];
  polyvecl s1; polyveck s2, t;
  int tries = 0;
  memcpy(in, seed, 32);
  for (;;) {
    in[32] = (unsigned char)tries;
    shake256(sseed, SEEDBYTES, in, 33);
    tries++;
    for (int i = 0; i < PARAM_L; i++) poly_uniform_eta1(&s1.vec[i], sseed, (unsigned char)i);
    for (int i = 0; i < PARAM_K; i++) poly_uniform_eta2(&s2.vec[i], sseed, (unsigned char)(PARAM_L + i));
    for (int i = 0; i < PARAM_L; i++)
      for (int j = 0; j < PARAM_N; j++) sh->s1[i * PARAM_N + j] = (int32_t)s1.vec[i].coeffs[j] - PARAM_Q;
    for (int i = 0; i < PARAM_K; i++)
      for (int j = 0; j < PARAM_N; j++) sh->s2[i * PARAM_N + j] = (int32_t)s2.vec[i].coeffs[j] - PARAM_Q;
    sh->S = th_spectral(sh->s1, sh->s2, TH_NU);
    if (sh->S <= TH_STHR) break;
    if (tries >= 255) abort();
  }
  sh->tries = tries;
  for (int i = 0; i < PARAM_L; i++) {
    for (int j = 0; j < PARAM_N; j++) sh->s1hat.vec[i].coeffs[j] = modq(sh->s1[i * PARAM_N + j]);
    poly_ntt(&sh->s1hat.vec[i]);
  }
  for (int i = 0; i < PARAM_K; i++) {
    for (int j = 0; j < PARAM_N; j++) sh->s2hat.vec[i].coeffs[j] = modq(sh->s2[i * PARAM_N + j]);
    poly_ntt(&sh->s2hat.vec[i]);
  }
  for (int i = 0; i < PARAM_K; i++) {
    polyvecl_pointwise_acc_invmontgomery(&t.vec[i], pub->mat + i, &sh->s1hat);
    poly_invntt_montgomery(t.vec + i);
    for (int j = 0; j < PARAM_N; j++) t.vec[i].coeffs[j] += modq(sh->s2[i * PARAM_N + j]);
  }
  polyveck_freeze4q(&t);
  sh->ti = t;
}

void th_pub_finish(th_pub *pub, const th_share *a, const th_share *b) {
  polyveck_add(&pub->t, &a->ti, &b->ti);
  polyveck_freeze4q(&pub->t);
  polyveck_power2round(&pub->t1, &pub->t0, &pub->t);
  pack_pk(pub->pk, pub->rho, &pub->t1);
  shake256(pub->tr, CRHBYTES, pub->pk, CRYPTO_PUBLICKEYBYTES);
  pub->t1hat_d = pub->t1;
  polyveck_shiftl(&pub->t1hat_d, PARAM_D);
  polyveck_ntt(&pub->t1hat_d);
}

/* ------------------------------------------------------------------ hyperball sampling */
static double u01(uint64_t x) { return ((double)(x >> 11) + 0.5) * (1.0 / 9007199254740992.0); }

void th_slot_sample(th_slot *s, const th_pub *pub, const unsigned char seed[32]) {
  static double G[DD + 2];
  unsigned char in[40], buf[SHAKE256_RATE];
  keccak_state st;
  unsigned int pos = SHAKE256_RATE;
  double ss = 0;
  memcpy(s->seed, seed, 32);
  memcpy(in, "THAIGIS/HB", 8);   /* domain tag (8 bytes) */
  memcpy(in + 8, seed, 32);
  shake256_absorb_once(&st, in, 40);
  for (int i = 0; i < DD + 2; i += 2) {
    uint64_t a = 0, b = 0;
    if (pos + 16 > SHAKE256_RATE) { shake256_squeezeblocks(buf, 1, &st); pos = 0; }
    for (int t = 0; t < 8; t++) { a |= (uint64_t)buf[pos + t] << (8 * t); b |= (uint64_t)buf[pos + 8 + t] << (8 * t); }
    pos += 16;
    double r = sqrt(-2.0 * log(u01(a))), th = 2.0 * M_PI * u01(b);
    G[i] = r * cos(th);
    G[i + 1] = r * sin(th);
  }
  for (int i = 0; i < DD + 2; i++) ss += G[i] * G[i];
  double sc = TH_RP / sqrt(ss);
  for (int i = 0; i < DD; i++) s->xi[i] = G[i] * sc;
  for (int i = 0; i < DZ; i++) s->y[i] = (int32_t)rint(TH_NU * s->xi[i]);
  for (int i = DZ; i < DD; i++) s->y[i] = (int32_t)rint(s->xi[i]);
  /* w = A y1 + y2 mod q */
  polyvecl y1;
  for (int i = 0; i < PARAM_L; i++) {
    for (int j = 0; j < PARAM_N; j++) y1.vec[i].coeffs[j] = modq(s->y[i * PARAM_N + j]);
    poly_ntt(&y1.vec[i]);
  }
  for (int i = 0; i < PARAM_K; i++) {
    polyvecl_pointwise_acc_invmontgomery(&s->w.vec[i], pub->mat + i, &y1);
    poly_invntt_montgomery(&s->w.vec[i]);
    for (int j = 0; j < PARAM_N; j++) s->w.vec[i].coeffs[j] += modq(s->y[DZ + i * PARAM_N + j]);
  }
  polyveck_freeze4q(&s->w);
}

/* ------------------------------------------------------------------ challenge */
void th_mu(unsigned char mu[CRHBYTES], const th_pub *pub, const unsigned char *m, size_t mlen,
           const unsigned char *ctx, size_t ctxlen) {
  /* mu = CRH(tr || 0x00 || |ctx| || ctx || M), exactly as PQMagic crypto_sign_signature/verify */
  keccak_state st;
  unsigned char hdr[2] = {0, (unsigned char)ctxlen};
  shake256_init(&st);
  shake256_absorb(&st, pub->tr, CRHBYTES);
  shake256_absorb(&st, hdr, 2);
  if (ctxlen) shake256_absorb(&st, ctx, ctxlen);
  shake256_absorb(&st, m, mlen);
  shake256_finalize(&st);
  shake256_squeeze(mu, CRHBYTES, &st);
}

void th_challenge(poly *c, const unsigned char mu[CRHBYTES], const polyveck *w0, const polyveck *w1) {
  polyveck w, hb, lb;
  polyveck_add(&w, w0, w1);
  polyveck_freeze4q(&w);
  polyveck_decompose(&hb, &lb, &w);
  challenge(c, mu, &hb);
}

/* ------------------------------------------------------------------ local rejection */
int th_local_rej(th_resp *out, const th_slot *s, const th_share *sh, const poly *c) {
  poly chat = *c, t;
  int32_t cs1[DZ], cs2[DW];
  double nrm = 0;
  poly_ntt(&chat);
  for (int i = 0; i < PARAM_L; i++) {
    poly_pointwise_invmontgomery(&t, &chat, &sh->s1hat.vec[i]);
    poly_invntt_montgomery(&t);
    for (int j = 0; j < PARAM_N; j++) cs1[i * PARAM_N + j] = center(freeze4q(t.coeffs[j]));
  }
  for (int i = 0; i < PARAM_K; i++) {
    poly_pointwise_invmontgomery(&t, &chat, &sh->s2hat.vec[i]);
    poly_invntt_montgomery(&t);
    for (int j = 0; j < PARAM_N; j++) cs2[i * PARAM_N + j] = center(freeze4q(t.coeffs[j]));
  }
  for (int i = 0; i < DZ; i++) { double v = s->xi[i] + cs1[i] / TH_NU; nrm += v * v; }
  for (int i = 0; i < DW; i++) { double v = s->xi[DZ + i] + cs2[i]; nrm += v * v; }
  out->accepted = (nrm <= TH_R * TH_R);
  if (out->accepted)
    for (int i = 0; i < DZ; i++) out->z1[i] = s->y[i] + cs1[i];
  return out->accepted;
}

/* ------------------------------------------------------------------ combine */
int th_combine(unsigned char sig[CRYPTO_BYTES], const th_pub *pub, const polyveck *w0, const polyveck *w1,
               const poly *c, const int32_t *z1a, const int32_t *z1b, int *why, unsigned *hintw) {
  polyvecl z, zhat;
  polyveck w, v, tmp2, h, dq;
  poly chat = *c;
  *why = 0; *hintw = 0;
  for (int i = 0; i < PARAM_L; i++)
    for (int j = 0; j < PARAM_N; j++) {
      int32_t x = z1a[i * PARAM_N + j] + z1b[i * PARAM_N + j];
      if (x >= GAMMA1 - BETA1 || -x >= GAMMA1 - BETA1) { *why = 1; return -1; }
      z.vec[i].coeffs[j] = modq(x);
    }
  /* v = A z - c t1 2^d, computed exactly as in crypto_sign_verify_internal */
  zhat = z;
  polyvecl_ntt(&zhat);
  for (int i = 0; i < PARAM_K; i++) polyvecl_pointwise_acc_invmontgomery(v.vec + i, pub->mat + i, &zhat);
  poly_ntt(&chat);
  for (int i = 0; i < PARAM_K; i++) poly_pointwise_invmontgomery(tmp2.vec + i, &chat, pub->t1hat_d.vec + i);
  polyveck_sub(&v, &v, &tmp2);
  polyveck_invntt_montgomery(&v);
  polyveck_freeze2q(&v);
  polyveck_add(&w, w0, w1);
  polyveck_freeze4q(&w);
  for (int i = 0; i < PARAM_K; i++)
    for (int j = 0; j < PARAM_N; j++) {
      int32_t d = center(modq((int64_t)w.vec[i].coeffs[j] - v.vec[i].coeffs[j]));
      if (d > GAMMA2 || -d > GAMMA2) { *why = 2; return -1; }
      dq.vec[i].coeffs[j] = modq(d);
    }
  unsigned n = polyveck_make_hint(&h, &v, &dq);
  *hintw = n;
  if (n > OMEGA) { *why = 3; return -1; }
  pack_sig(sig, &z, &h, c);
  return 0;
}

/* ------------------------------------------------------------------ helpers */
void th_vecw_pack(unsigned char *out, const polyveck *w) {
  uint64_t acc = 0; int nb = 0; size_t o = 0;
  for (int i = 0; i < PARAM_K; i++)
    for (int j = 0; j < PARAM_N; j++) {
      acc = (acc << QBITS) | w->vec[i].coeffs[j];
      nb += QBITS;
      while (nb >= 8) { out[o++] = (unsigned char)(acc >> (nb - 8)); nb -= 8; }
    }
  if (nb) out[o++] = (unsigned char)(acc << (8 - nb));
}
