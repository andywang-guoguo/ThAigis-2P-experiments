/* N/R/C canonical lossless codec for partial responses (signed integer vectors).
 *
 *   ZZ(x) = 2x (x>=0), -2x-1 (x<0) maps [-(q-1)/2,(q-1)/2] onto [0,q-1]; b_q = QBITS.
 *   mode N (0x00): byte b, then x+2^(b-1) on b bits (b minimal, 1<=b<=b_q)
 *   mode R (0x01): ZZ(x) on b_q bits
 *   mode C (0x02): blocks of 64 coefficients; per block a parameter byte a:
 *                  a in [0,b_q-1] -> truncated Rice: t=u>>a; t<15: 1^t 0 rem_a ; t>=15: 1^15 u_(b_q)
 *                  a = b_q        -> 64 raw b_q-bit values
 *                  each block padded with zero bits to a byte boundary
 *   The encoder outputs the shortest mode (ties N<R<C; inside C ties -> smaller a).
 *   The decoder is strict and finally checks Encode(Decode(e)) == e.
 */
#include <string.h>
#include <stdlib.h>
#include "thaigis.h"

#define BQ QBITS
#define BLK 64
#define ESC 15

typedef struct { unsigned char *p; size_t n; unsigned acc; int nb; } bw_t;
static void bw_put(bw_t *w, uint32_t v, int bits) {
  for (int i = bits - 1; i >= 0; i--) {
    w->acc = (w->acc << 1) | ((v >> i) & 1u);
    if (++w->nb == 8) { if (w->p) w->p[w->n] = (unsigned char)w->acc; w->n++; w->acc = 0; w->nb = 0; }
  }
}
static void bw_flush(bw_t *w) { while (w->nb) bw_put(w, 0, 1); }

typedef struct { const unsigned char *p; size_t n, pos; int bit; int err; } br_t;
static uint32_t br_get(br_t *r, int bits) {
  uint32_t v = 0;
  for (int i = 0; i < bits; i++) {
    if (r->pos >= r->n) { r->err = 1; return 0; }
    v = (v << 1) | ((r->p[r->pos] >> (7 - r->bit)) & 1u);
    if (++r->bit == 8) { r->bit = 0; r->pos++; }
  }
  return v;
}
static int br_align_zero(br_t *r) {          /* remaining bits of current byte must be zero */
  while (r->bit) { if (br_get(r, 1)) return -1; }
  return r->err ? -1 : 0;
}

static inline uint32_t zz(int32_t x) { return x >= 0 ? 2u * (uint32_t)x : (uint32_t)(-2 * (int64_t)x - 1); }
static inline int32_t unzz(uint32_t u) { return (u & 1) ? -(int32_t)((u + 1) >> 1) : (int32_t)(u >> 1); }

static size_t rice_bits(const uint32_t *u, int a) {
  size_t bits = 0;
  for (int i = 0; i < BLK; i++) { uint32_t t = u[i] >> a; bits += (t < ESC) ? t + 1 + a : ESC + BQ; }
  return bits;
}
static int best_param(const uint32_t *u, size_t *bytes) {
  int best = BQ; size_t bb = (size_t)BLK * BQ;
  bb = (bb + 7) / 8;
  for (int a = BQ - 1; a >= 0; a--) {           /* descending, '<=' keeps the smallest a on ties */
    size_t by = (rice_bits(u, a) + 7) / 8;
    if (by <= bb) { bb = by; best = a; }
  }
  *bytes = 1 + bb;
  return best;
}

static size_t enc_N(unsigned char *out, const int32_t *x, size_t len, int b) {
  bw_t w = {out, 0, 0, 0};
  bw_put(&w, 0x00, 8); bw_put(&w, (uint32_t)b, 8);
  for (size_t i = 0; i < len; i++) bw_put(&w, (uint32_t)(x[i] + (1 << (b - 1))), b);
  bw_flush(&w);
  return w.n;
}
static size_t enc_R(unsigned char *out, const int32_t *x, size_t len) {
  bw_t w = {out, 0, 0, 0};
  bw_put(&w, 0x01, 8);
  for (size_t i = 0; i < len; i++) bw_put(&w, zz(x[i]), BQ);
  bw_flush(&w);
  return w.n;
}
static size_t enc_C(unsigned char *out, const int32_t *x, size_t len) {
  bw_t w = {out, 0, 0, 0};
  uint32_t u[BLK];
  bw_put(&w, 0x02, 8);
  for (size_t b0 = 0; b0 < len; b0 += BLK) {
    size_t by;
    for (int i = 0; i < BLK; i++) u[i] = zz(x[b0 + i]);
    int a = best_param(u, &by);
    bw_put(&w, (uint32_t)a, 8);
    for (int i = 0; i < BLK; i++) {
      if (a == BQ) { bw_put(&w, u[i], BQ); continue; }
      uint32_t t = u[i] >> a;
      if (t < ESC) { for (uint32_t k = 0; k < t; k++) bw_put(&w, 1, 1); bw_put(&w, 0, 1); bw_put(&w, u[i] & ((1u << a) - 1), a); }
      else { for (int k = 0; k < ESC; k++) bw_put(&w, 1, 1); bw_put(&w, u[i], BQ); }
    }
    bw_flush(&w);
  }
  return w.n;
}

size_t th_encode(unsigned char *out, const int32_t *x, size_t len, int *mode) {
  int b = 1;
  for (size_t i = 0; i < len; i++)
    while (x[i] < -(1 << (b - 1)) || x[i] > (1 << (b - 1)) - 1) b++;
  size_t lN = 2 + (len * (size_t)b + 7) / 8;
  size_t lR = 1 + (len * (size_t)BQ + 7) / 8;
  size_t lC = enc_C(NULL, x, len);
  if (lN <= lR && lN <= lC) { *mode = 0; return enc_N(out, x, len, b); }
  if (lR <= lC) { *mode = 1; return enc_R(out, x, len); }
  *mode = 2; return enc_C(out, x, len);
}

int th_decode(int32_t *x, size_t len, const unsigned char *in, size_t inlen) {
  br_t r = {in, inlen, 0, 0, 0};
  if (inlen < 1) return -1;
  uint32_t mode = br_get(&r, 8);
  if (mode == 0) {
    uint32_t b = br_get(&r, 8);
    if (r.err || b < 1 || b > BQ) return -1;
    if (inlen != 2 + (len * b + 7) / 8) return -1;
    for (size_t i = 0; i < len; i++) {
      int64_t v = (int64_t)br_get(&r, (int)b) - (1 << (b - 1));
      if (v > (PARAM_Q - 1) / 2 || -v > (PARAM_Q - 1) / 2) return -1;
      x[i] = (int32_t)v;
    }
    if (br_align_zero(&r)) return -1;
  } else if (mode == 1) {
    if (inlen != 1 + (len * BQ + 7) / 8) return -1;
    for (size_t i = 0; i < len; i++) {
      uint32_t u = br_get(&r, BQ);
      if (u >= PARAM_Q) return -1;
      x[i] = unzz(u);
    }
    if (br_align_zero(&r)) return -1;
  } else if (mode == 2) {
    if (len % BLK) return -1;
    for (size_t b0 = 0; b0 < len; b0 += BLK) {
      uint32_t a = br_get(&r, 8);
      if (r.err || a > BQ) return -1;
      for (int i = 0; i < BLK; i++) {
        uint32_t u;
        if (a == BQ) u = br_get(&r, BQ);
        else {
          uint32_t t = 0;
          while (t < ESC && br_get(&r, 1) == 1) t++;
          if (r.err) return -1;
          if (t < ESC) u = (t << a) | br_get(&r, (int)a);
          else { u = br_get(&r, BQ); if ((u >> a) < ESC) return -1; }
        }
        if (r.err || u >= PARAM_Q) return -1;
        x[b0 + i] = unzz(u);
      }
      if (br_align_zero(&r)) return -1;
    }
  } else return -1;
  if (r.err || r.pos != inlen || r.bit != 0) return -1;
  /* canonicity: re-encode and compare */
  unsigned char *tmp = malloc(inlen + 4 * len + 64);
  int m;
  size_t l2 = th_encode(tmp, x, len, &m);
  int ok = (l2 == inlen) && memcmp(tmp, in, inlen) == 0;
  free(tmp);
  return ok ? 0 : -1;
}
