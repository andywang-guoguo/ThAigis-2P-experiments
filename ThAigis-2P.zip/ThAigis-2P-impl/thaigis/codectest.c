/* Tests for the N/R/C codec: round trips on real partial responses and synthetic
 * vectors, plus malformed / non-canonical inputs.  Prints a JSON summary. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "thaigis.h"
#include "sign.h"
#include "utils/randombytes.h"

#define BQ QBITS
static long rt_ok = 0, rt_fail = 0, bad_rejected = 0, bad_accepted = 0, flip_valid_other = 0, flip_rejected = 0, flip_bug = 0;
static unsigned char E[8 * DZ + 64], F[8 * DZ + 64];
static int32_t X[DZ], Y[DZ];

static uint32_t rnd32(void) { uint32_t v; randombytes((uint8_t *)&v, 4); return v; }
static double gauss(void) { double u1 = (rnd32() + 0.5) / 4294967296.0, u2 = (rnd32() + 0.5) / 4294967296.0; return sqrt(-2 * log(u1)) * cos(2 * M_PI * u2); }

static void roundtrip(const int32_t *x) {
  int md; size_t l = th_encode(E, x, DZ, &md);
  if (th_decode(Y, DZ, E, l) == 0 && memcmp(x, Y, sizeof Y) == 0) rt_ok++; else rt_fail++;
  /* truncation and extension must fail */
  for (int t = 1; t <= 3; t++) { if (th_decode(Y, DZ, E, l - t) == 0) bad_accepted++; else bad_rejected++; }
  memcpy(F, E, l); F[l] = 0; if (th_decode(Y, DZ, F, l + 1) == 0) bad_accepted++; else bad_rejected++;
  /* random single-bit flips: either rejected, or a different vector whose canonical encoding is exactly F */
  for (int t = 0; t < 16; t++) {
    memcpy(F, E, l);
    size_t pos = rnd32() % l; F[pos] ^= (unsigned char)(1u << (rnd32() % 8));
    if (th_decode(Y, DZ, F, l) != 0) { flip_rejected++; continue; }
    int m2; unsigned char G[8 * DZ + 64]; size_t l2 = th_encode(G, Y, DZ, &m2);
    if (l2 == l && memcmp(G, F, l) == 0 && memcmp(Y, x, sizeof Y) != 0) flip_valid_other++; else flip_bug++;
  }
}

/* write a vector in a fixed (possibly non-optimal) mode, bypassing the encoder's choice */
static size_t put_bits(unsigned char *o, size_t *bitpos, uint32_t v, int bits) {
  for (int i = bits - 1; i >= 0; i--) { size_t B = *bitpos >> 3; int b = 7 - (*bitpos & 7); if (b == 7) o[B] = 0; o[B] |= ((v >> i) & 1) << b; (*bitpos)++; }
  return (*bitpos + 7) >> 3;
}
static uint32_t zz(int32_t x) { return x >= 0 ? 2u * (uint32_t)x : (uint32_t)(-2 * (int64_t)x - 1); }

int main(void) {
  /* real partial responses from the protocol */
  th_pub pub; th_share sh[2]; unsigned char rho[32], s0[32], s1[32];
  randombytes(rho, 32); randombytes(s0, 32); randombytes(s1, 32);
  th_pub_init(&pub, rho); th_share_sample(&sh[0], &pub, s0); th_share_sample(&sh[1], &pub, s1); th_pub_finish(&pub, &sh[0], &sh[1]);
  static th_slot sl; th_resp rs; poly c; unsigned char mu[CRHBYTES], m[32];
  int real = 0;
  while (real < 300) {
    unsigned char sd[32]; randombytes(sd, 32); randombytes(m, 32);
    th_slot_sample(&sl, &pub, sd); th_mu(mu, &pub, m, 32, NULL, 0); th_challenge(&c, mu, &sl.w, &sl.w);
    if (th_local_rej(&rs, &sl, &sh[0], &c)) { roundtrip(rs.z1); real++; }
  }
  /* synthetic distributions */
  int synth = 0;
  for (int t = 0; t < 400; t++) {
    int kind = t % 8;
    for (int i = 0; i < DZ; i++) {
      int64_t v;
      switch (kind) {
        case 0: v = (int64_t)(rnd32() % PARAM_Q) - (PARAM_Q - 1) / 2; break;            /* full range */
        case 1: v = 0; break;                                                             /* all zero */
        case 2: v = (rnd32() & 1) ? (PARAM_Q - 1) / 2 : -(PARAM_Q - 1) / 2; break;        /* extremes */
        case 3: v = llround(gauss() * 20000); break;
        case 4: v = llround(gauss() * 300); break;
        case 5: v = (rnd32() % 64 == 0) ? (int64_t)(rnd32() % PARAM_Q) - (PARAM_Q - 1) / 2 : llround(gauss() * 50); break; /* sparse outliers */
        case 6: v = (int64_t)(rnd32() % 3) - 1; break;
        default: v = (i < DZ / 2) ? llround(gauss() * 100) : llround(gauss() * 200000); break;
      }
      if (v > (PARAM_Q - 1) / 2) v = (PARAM_Q - 1) / 2;
      if (v < -(PARAM_Q - 1) / 2) v = -(PARAM_Q - 1) / 2;
      X[i] = (int32_t)v;
    }
    roundtrip(X); synth++;
  }
  /* targeted malformed inputs */
  long targeted = 0, targeted_rejected = 0;
  #define EXPECT_REJECT(buf, len) do { targeted++; if (th_decode(Y, DZ, buf, len) != 0) targeted_rejected++; } while (0)
  for (int i = 0; i < DZ; i++) X[i] = (int32_t)llround(gauss() * 20000);
  int md; size_t l = th_encode(E, X, DZ, &md);
  /* unknown mode bytes */
  for (int mb = 3; mb < 256; mb += 17) { memcpy(F, E, l); F[0] = (unsigned char)mb; EXPECT_REJECT(F, l); }
  /* mode N with illegal widths */
  { unsigned char G[8 * DZ]; G[0] = 0; G[1] = 0; EXPECT_REJECT(G, 2 + 0); G[1] = BQ + 1; EXPECT_REJECT(G, 2 + (DZ * (BQ + 1) + 7) / 8); }
  /* same vector in mode R although C is shorter (non-canonical) */
  { size_t bp = 0; unsigned char G[8 * DZ]; put_bits(G, &bp, 1, 8); for (int i = 0; i < DZ; i++) put_bits(G, &bp, zz(X[i]), BQ); EXPECT_REJECT(G, (bp + 7) / 8); }
  /* mode R with a value u >= q */
  { size_t bp = 0; unsigned char G[8 * DZ]; put_bits(G, &bp, 1, 8); for (int i = 0; i < DZ; i++) put_bits(G, &bp, i == 5 ? PARAM_Q : (uint32_t)(rnd32() % PARAM_Q), BQ); EXPECT_REJECT(G, (bp + 7) / 8); }
  /* mode C with the escape used for a small value (non-canonical escape) */
  { size_t bp = 0; unsigned char G[8 * DZ]; put_bits(G, &bp, 2, 8);
    for (int b = 0; b < DZ / 64; b++) { put_bits(G, &bp, 4, 8); for (int i = 0; i < 64; i++) { if (b == 0 && i == 0) { put_bits(G, &bp, 0x7FFF, 15); put_bits(G, &bp, 3, BQ); } else { put_bits(G, &bp, 0, 1); put_bits(G, &bp, 0, 4); } } while (bp & 7) put_bits(G, &bp, 0, 1); }
    EXPECT_REJECT(G, (bp + 7) / 8); }
  /* mode C with illegal block parameter */
  { memcpy(F, E, l); if (F[0] == 2) { F[1] = BQ + 1; EXPECT_REJECT(F, l); } }
  /* nonzero padding bit inside a mode-C block: x = (1,0,...,0) is encoded in mode C,
     block 0 uses a = 0 and occupies 66 bits, so the last data byte of block 0 has 6 padding bits */
  { int32_t Z[DZ]; memset(Z, 0, sizeof Z); Z[0] = 1; size_t ln = th_encode(F, Z, DZ, &md);
    if (md == 2 && F[1] == 0) { F[10] |= 1; EXPECT_REJECT(F, ln); } else { targeted++; printf("padding test setup failed\n"); } }
  printf("{\"set\":%d,\"real_vectors\":%d,\"synthetic_vectors\":%d,\"roundtrip_ok\":%ld,\"roundtrip_fail\":%ld,"
         "\"trunc_ext_rejected\":%ld,\"trunc_ext_accepted\":%ld,\"flip_rejected\":%ld,\"flip_valid_other_vector\":%ld,\"flip_bug\":%ld,"
         "\"targeted\":%ld,\"targeted_rejected\":%ld}\n",
         PARAMS, real, synth, rt_ok, rt_fail, bad_rejected, bad_accepted, flip_rejected, flip_valid_other, flip_bug, targeted, targeted_rejected);
  return 0;
}
