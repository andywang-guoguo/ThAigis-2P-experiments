/* ThAigis-2P reference implementation (research prototype, not constant time).
 *
 * Built on top of the vendored PQMagic Aigis-sig code (pqm/aigis).  The final
 * signatures are checked with the unmodified crypto_sign_verify().
 *
 * Contents
 *   - parameters (nu, r, r', S_thr) for Aigis-sig I/II/III
 *   - native-distribution key shares with the spectral bound check
 *   - hyperball sampling (double precision), commitments w = A y1 + y2
 *   - local rejection, combine (hint), N/R/C lossless codec
 */
#ifndef THAIGIS_H
#define THAIGIS_H
#include <stdint.h>
#include <stddef.h>
#include "params.h"
#include "poly.h"
#include "polyvec.h"

#define DZ (PARAM_L * PARAM_N)      /* length of first response component */
#define DW (PARAM_K * PARAM_N)      /* length of commitment / second component */
#define DD (DZ + DW)                /* hyperball dimension D = n(k+l) */
#define TAU 60
#define KMAX 64

#if PARAMS == 1
#define TH_NU 1.25
#define TH_R 670000.0
#define TH_RP 670259.0
#define TH_STHR 12259.0     /* spectral threshold, median of native shares (see results/final_params.json) */
#elif PARAMS == 2
#define TH_NU 0.75
#define TH_R 1300000.0
#define TH_RP 1300394.0
#define TH_STHR 36099.0
#elif PARAMS == 3
#define TH_NU 0.6
#define TH_R 1600000.0
#define TH_RP 1600369.0
#define TH_STHR 38423.0
#endif

typedef struct {
  int32_t s1[DZ];            /* signed coefficients of s1^(i) */
  int32_t s2[DW];            /* signed coefficients of s2^(i) */
  polyvecl s1hat;            /* NTT domain (for c*s) */
  polyveck s2hat;
  polyveck ti;               /* partial public key t_i = A s1 + s2 (mod q) */
  double S;                  /* spectral statistic of the share */
  int tries;                 /* number of samples drawn before the check passed */
} th_share;

typedef struct {
  unsigned char rho[SEEDBYTES];
  polyvecl mat[PARAM_K];     /* A in NTT domain, as produced by expand_mat */
  polyveck t;                /* full t = t_0 + t_1 */
  polyveck t1, t0;
  polyveck t1hat_d;          /* NTT(t1 << d) */
  unsigned char pk[CRYPTO_PUBLICKEYBYTES];
  unsigned char tr[CRHBYTES];
} th_pub;

typedef struct {             /* one slot (parallel instance) of one party */
  unsigned char seed[32];
  double xi[DD];
  int32_t y[DD];
  polyveck w;                /* commitment, mod q */
} th_slot;

typedef struct {
  int accepted;              /* local rejection outcome */
  int32_t z1[DZ];            /* first component of partial response */
} th_resp;

/* key generation */
double th_spectral(const int32_t *s1, const int32_t *s2, double nu);
void th_share_sample(th_share *sh, const th_pub *pub, const unsigned char seed[32]);
void th_pub_init(th_pub *pub, const unsigned char rho[SEEDBYTES]);
void th_pub_finish(th_pub *pub, const th_share *a, const th_share *b);

/* signing */
void th_slot_sample(th_slot *s, const th_pub *pub, const unsigned char seed[32]);
void th_mu(unsigned char mu[CRHBYTES], const th_pub *pub, const unsigned char *m, size_t mlen,
           const unsigned char *ctx, size_t ctxlen);
void th_challenge(poly *c, const unsigned char mu[CRHBYTES], const polyveck *w0, const polyveck *w1);
int th_local_rej(th_resp *out, const th_slot *s, const th_share *sh, const poly *c);
int th_combine(unsigned char sig[CRYPTO_BYTES], const th_pub *pub, const polyveck *w0, const polyveck *w1,
               const poly *c, const int32_t *z1a, const int32_t *z1b, int *why, unsigned *hintw);

/* N/R/C codec */
size_t th_encode(unsigned char *out, const int32_t *x, size_t len, int *mode);
int th_decode(int32_t *x, size_t len, const unsigned char *in, size_t inlen);

/* helpers */
void th_vecw_pack(unsigned char *out, const polyveck *w);   /* QBITS bits per coefficient */
#define TH_WBYTES (DW * QBITS / 8)
#endif
