# ThAigis-2P 参考实现

本目录是论文第 7 节所用的 C 参考实现和第 6 节参数计算脚本。实现在一个进程中模拟两方，不含网络、认证和持久化状态服务，也没有做常数时间处理，只用于正确性验证和性能测量。

## 目录

- `pqm/`：取自 PQMagic（https://github.com/pqcrypto-cn/PQMagic）的 Aigis-sig 源码（sig/aigis-sig/std），按 PQMagic 的原许可证使用。只保留了 SHAKE 实例；`pqm/hash/keccak/fips202.c` 是独立编写的 Keccak，已与 Python 标准库的 SHAKE 输出逐字节比对。
- `thaigis/thaigis.h`、`thaigis.c`：谱检查与份额生成（ShareGen）、超球体采样（HSample）、局部拒绝（LocalRej）、挑战计算和合并（Combine）。三组参数的 ν、r、r′、S_thr 定义在 `thaigis.h` 中。
- `thaigis/codec.c`：第 4.8 节的 N/R/C 规范编码与严格解码。
- `thaigis/bench.c`：门限签名的统计与计时程序，每 50 个签名更换一次密钥，输出 JSON。
- `thaigis/codectest.c`：编码器测试（一致性、截断、非法输入、比特翻转）。
- `scripts/`：参数选取（`final_params.py`）、成功率模型（`thaigis_model.py`）、密钥平均（`keyavg.py`）、core-SVP 估计（`coresvp.py`、`security_est.py`）及其他补充实验。需要 Python 3、numpy、scipy、mpmath。
- `results/`：论文中各表所用的原始输出。

## 编译与运行

```
make                    # 生成 bin/bench{1,2,3} 和 bin/codectest{1,2,3}，数字为参数集
./bin/bench1 2000 8 1   # 参数集 I：2000 个签名，K=8，随机种子 1
./bin/codectest2        # 参数集 II 的编码测试
python3 scripts/final_params.py   # 重新计算表 2 的参数
```

需要 GCC 和 Linux（随机数取自 `getrandom`）。
