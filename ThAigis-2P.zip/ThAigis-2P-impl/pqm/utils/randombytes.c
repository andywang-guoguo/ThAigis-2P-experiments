#include <stdio.h>
#include <stdlib.h>
#include <sys/random.h>
#include "randombytes.h"

void randombytes(uint8_t *out, size_t outlen) {
  while (outlen > 0) {
    ssize_t r = getrandom(out, outlen > 256 ? 256 : outlen, 0);
    if (r <= 0) { perror("getrandom"); abort(); }
    out += r; outlen -= (size_t)r;
  }
}
