#ifndef PQMAGIC_CONFIG_H
#define PQMAGIC_CONFIG_H
/* Minimal replacement for PQMagic's global config: no symbol namespacing. */
#define GLOBAL_NAMESPACE(s) s
#define PQMAGIC_EXPORT
#endif
