#ifndef SIGN_H
#define SIGN_H
#include <stddef.h>
#include "params.h"
#include "poly.h"
#include "polyvec.h"

void expand_mat(polyvecl mat[PARAM_K], const unsigned char rho[SEEDBYTES]);
void challenge(poly *c, const unsigned char mu[CRHBYTES], const polyveck *w1);

int crypto_sign_keypair_internal(unsigned char *pk, unsigned char *sk, const unsigned char *coins);
int crypto_sign_keypair(unsigned char *pk, unsigned char *sk);
int crypto_sign_signature_internal(unsigned char *sig, size_t *siglen,
                                   const unsigned char *m, size_t mlen, const unsigned char *sk);
int crypto_sign_signature(unsigned char *sig, size_t *siglen, const unsigned char *m, size_t mlen,
                          const unsigned char *ctx, size_t ctx_len, const unsigned char *sk);
int crypto_sign_verify_internal(const unsigned char *sig, size_t siglen,
                                const unsigned char *m, size_t mlen, const unsigned char *pk);
int crypto_sign_verify(const unsigned char *sig, size_t siglen, const unsigned char *m, size_t mlen,
                       const unsigned char *ctx, size_t ctx_len, const unsigned char *pk);
#endif
