#ifndef POLYVEC_H
#define POLYVEC_H

#include <stdint.h>
#include "params.h"
#include "poly.h"

typedef struct {
  poly vec[PARAM_L];
} polyvecl;

typedef struct {
  poly vec[PARAM_K];
} polyveck;

void polyvecl_freeze2q(polyvecl *v);
void polyvecl_freeze4q(polyvecl *v);
void polyvecl_add(polyvecl *w, const polyvecl *u, const polyvecl *v);
void polyvecl_ntt(polyvecl *v);
void polyvecl_pointwise_acc_invmontgomery(poly *w, const polyvecl *u, const polyvecl *v);
int polyvecl_chknorm(const polyvecl *v, uint32_t bound);

void polyveck_freeze2q(polyveck *v);
void polyveck_freeze4q(polyveck *v);
void polyveck_add(polyveck *w, const polyveck *u, const polyveck *v);
void polyveck_sub(polyveck *w, const polyveck *u, const polyveck *v);
void polyveck_neg(polyveck *v);
void polyveck_shiftl(polyveck *v, unsigned int k);
void polyveck_ntt(polyveck *v);
void polyveck_invntt_montgomery(polyveck *v);
int polyveck_chknorm(const polyveck *v, uint32_t bound);
void polyveck_power2round(polyveck *v1, polyveck *v0, const polyveck *v);
void polyveck_decompose(polyveck *v1, polyveck *v0, const polyveck *v);
unsigned int polyveck_make_hint(polyveck *h, const polyveck *u, const polyveck *v);
void polyveck_use_hint(polyveck *w, const polyveck *u, const polyveck *h);

#endif
