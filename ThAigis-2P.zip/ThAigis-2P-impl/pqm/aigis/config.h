#ifndef CONFIG_H
#define CONFIG_H

#ifndef AIGIS_SIG_MODE
#define AIGIS_SIG_MODE 2
#endif

#define PARAMS AIGIS_SIG_MODE

#if PARAMS == 1
#define CRYPTO_ALGNAME "Aigis_sig1"
#elif PARAMS == 2
#define CRYPTO_ALGNAME "Aigis_sig2"
#elif PARAMS == 3
#define CRYPTO_ALGNAME "Aigis_sig3"
#endif

/* Each parameter set is compiled into its own binary, so no symbol namespacing. */
#define AIGIS_SIG_NAMESPACE(s) s

#endif
