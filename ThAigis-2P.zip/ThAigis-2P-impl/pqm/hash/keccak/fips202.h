#ifndef FIPS202_H
#define FIPS202_H

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

#define SHAKE128_RATE 168
#define SHAKE256_RATE 136

typedef struct {
  uint64_t s[25];
  unsigned int pos;
} keccak_state;

void shake128_absorb_once(keccak_state *state, const uint8_t *in, size_t inlen);
void shake128_squeezeblocks(uint8_t *output, size_t nblocks, keccak_state *state);
void shake128_squeeze(uint8_t *out, size_t outlen, keccak_state *state);
void shake128(uint8_t *output, size_t outlen, const uint8_t *input, size_t inlen);

void shake256_init(keccak_state *state);
void shake256_absorb(keccak_state *state, const uint8_t *in, size_t inlen);
void shake256_finalize(keccak_state *state);
void shake256_squeeze(uint8_t *out, size_t outlen, keccak_state *state);
void shake256_absorb_once(keccak_state *state, const uint8_t *input, size_t inlen);
void shake256_squeezeblocks(uint8_t *output, size_t nblocks, keccak_state *state);
void shake256(uint8_t *output, size_t outlen, const uint8_t *input, size_t inlen);

#endif
