/* Compact Keccak / SHAKE implementation exposing the same API and semantics as
 * PQMagic hash/keccak/fips202.c (which is itself derived from the public-domain
 * TweetFips202 / SUPERCOP code).  The permutation below is the standard
 * loop-based Keccak-f[1600]; correctness is checked against Python hashlib
 * (scripts/test_fips202.py). */
#include <string.h>
#include "fips202.h"

static const uint64_t RC[24] = {
  0x0000000000000001ULL, 0x0000000000008082ULL, 0x800000000000808aULL,
  0x8000000080008000ULL, 0x000000000000808bULL, 0x0000000080000001ULL,
  0x8000000080008081ULL, 0x8000000000008009ULL, 0x000000000000008aULL,
  0x0000000000000088ULL, 0x0000000080008009ULL, 0x000000008000000aULL,
  0x000000008000808bULL, 0x800000000000008bULL, 0x8000000000008089ULL,
  0x8000000000008003ULL, 0x8000000000008002ULL, 0x8000000000000080ULL,
  0x000000000000800aULL, 0x800000008000000aULL, 0x8000000080008081ULL,
  0x8000000000008080ULL, 0x0000000080000001ULL, 0x8000000080008008ULL};
static const int ROTC[24] = {1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 2, 14,
                             27, 41, 56, 8, 25, 43, 62, 18, 39, 61, 20, 44};
static const int PILN[24] = {10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4,
                             15, 23, 19, 13, 12, 2, 20, 14, 22, 9, 6, 1};
#define ROL(a, o) (((a) << (o)) | ((a) >> (64 - (o))))

static void keccakf(uint64_t st[25]) {
  int i, j, r;
  uint64_t t, bc[5];
  for (r = 0; r < 24; r++) {
    for (i = 0; i < 5; i++)
      bc[i] = st[i] ^ st[i + 5] ^ st[i + 10] ^ st[i + 15] ^ st[i + 20];
    for (i = 0; i < 5; i++) {
      t = bc[(i + 4) % 5] ^ ROL(bc[(i + 1) % 5], 1);
      for (j = 0; j < 25; j += 5) st[j + i] ^= t;
    }
    t = st[1];
    for (i = 0; i < 24; i++) {
      j = PILN[i];
      bc[0] = st[j];
      st[j] = ROL(t, ROTC[i]);
      t = bc[0];
    }
    for (j = 0; j < 25; j += 5) {
      for (i = 0; i < 5; i++) bc[i] = st[j + i];
      for (i = 0; i < 5; i++) st[j + i] ^= (~bc[(i + 1) % 5]) & bc[(i + 2) % 5];
    }
    st[0] ^= RC[r];
  }
}

static uint64_t load64(const uint8_t *x) {
  uint64_t r = 0;
  for (int i = 0; i < 8; i++) r |= (uint64_t)x[i] << (8 * i);
  return r;
}
static void store64(uint8_t *x, uint64_t u) {
  for (int i = 0; i < 8; i++) { x[i] = (uint8_t)u; u >>= 8; }
}

static void keccak_absorb_once(uint64_t s[25], unsigned int r, const uint8_t *in,
                               size_t inlen, uint8_t p) {
  unsigned int i;
  uint8_t t[200];
  for (i = 0; i < 25; i++) s[i] = 0;
  while (inlen >= r) {
    for (i = 0; i < r / 8; i++) s[i] ^= load64(in + 8 * i);
    keccakf(s);
    inlen -= r; in += r;
  }
  memset(t, 0, sizeof t);
  memcpy(t, in, inlen);
  t[inlen] = p;
  t[r - 1] |= 128;
  for (i = 0; i < r / 8; i++) s[i] ^= load64(t + 8 * i);
}

static void keccak_squeezeblocks(uint8_t *out, size_t nblocks, uint64_t s[25], unsigned int r) {
  while (nblocks > 0) {
    keccakf(s);
    for (unsigned int i = 0; i < r / 8; i++) store64(out + 8 * i, s[i]);
    out += r; nblocks--;
  }
}

static unsigned int keccak_squeeze(uint8_t *out, size_t outlen, uint64_t s[25],
                                   unsigned int pos, unsigned int r) {
  unsigned int i;
  while (outlen) {
    if (pos == r) { keccakf(s); pos = 0; }
    for (i = pos; i < r && i < pos + outlen; i++) *out++ = (uint8_t)(s[i / 8] >> (8 * (i % 8)));
    outlen -= i - pos;
    pos = i;
  }
  return pos;
}

static unsigned int keccak_absorb(uint64_t s[25], unsigned int pos, unsigned int r,
                                  const uint8_t *in, size_t inlen) {
  unsigned int i;
  while (pos + inlen >= r) {
    for (i = pos; i < r; i++) s[i / 8] ^= (uint64_t)*in++ << (8 * (i % 8));
    inlen -= r - pos;
    keccakf(s);
    pos = 0;
  }
  for (i = pos; i < pos + inlen; i++) s[i / 8] ^= (uint64_t)*in++ << (8 * (i % 8));
  return i;
}

void shake128_absorb_once(keccak_state *st, const uint8_t *in, size_t inlen) {
  keccak_absorb_once(st->s, SHAKE128_RATE, in, inlen, 0x1F);
  st->pos = SHAKE128_RATE;
}
void shake128_squeezeblocks(uint8_t *out, size_t nblocks, keccak_state *st) {
  keccak_squeezeblocks(out, nblocks, st->s, SHAKE128_RATE);
}
void shake128_squeeze(uint8_t *out, size_t outlen, keccak_state *st) {
  st->pos = keccak_squeeze(out, outlen, st->s, st->pos, SHAKE128_RATE);
}
void shake128(uint8_t *out, size_t outlen, const uint8_t *in, size_t inlen) {
  keccak_state st;
  size_t nb;
  shake128_absorb_once(&st, in, inlen);
  nb = outlen / SHAKE128_RATE;
  shake128_squeezeblocks(out, nb, &st);
  out += nb * SHAKE128_RATE; outlen -= nb * SHAKE128_RATE;
  shake128_squeeze(out, outlen, &st);
}

void shake256_init(keccak_state *st) { memset(st->s, 0, sizeof st->s); st->pos = 0; }
void shake256_absorb(keccak_state *st, const uint8_t *in, size_t inlen) {
  st->pos = keccak_absorb(st->s, st->pos, SHAKE256_RATE, in, inlen);
}
void shake256_finalize(keccak_state *st) {
  st->s[st->pos / 8] ^= (uint64_t)0x1F << (8 * (st->pos % 8));
  st->s[SHAKE256_RATE / 8 - 1] ^= 1ULL << 63;
  st->pos = SHAKE256_RATE;
}
void shake256_squeeze(uint8_t *out, size_t outlen, keccak_state *st) {
  st->pos = keccak_squeeze(out, outlen, st->s, st->pos, SHAKE256_RATE);
}
void shake256_absorb_once(keccak_state *st, const uint8_t *in, size_t inlen) {
  keccak_absorb_once(st->s, SHAKE256_RATE, in, inlen, 0x1F);
  st->pos = SHAKE256_RATE;
}
void shake256_squeezeblocks(uint8_t *out, size_t nblocks, keccak_state *st) {
  keccak_squeezeblocks(out, nblocks, st->s, SHAKE256_RATE);
}
void shake256(uint8_t *out, size_t outlen, const uint8_t *in, size_t inlen) {
  keccak_state st;
  size_t nb;
  shake256_absorb_once(&st, in, inlen);
  nb = outlen / SHAKE256_RATE;
  shake256_squeezeblocks(out, nb, &st);
  out += nb * SHAKE256_RATE; outlen -= nb * SHAKE256_RATE;
  shake256_squeeze(out, outlen, &st);
}
